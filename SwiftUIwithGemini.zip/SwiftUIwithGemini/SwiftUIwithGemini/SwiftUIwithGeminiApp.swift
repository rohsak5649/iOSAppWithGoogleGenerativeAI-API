//
//  SwiftUIwithGeminiApp.swift
//  SwiftUIwithGemini
//
//  Created by Rohan Sakhare on 08/06/24.
//

import SwiftUI

@main
struct SwiftUIwithGeminiApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
